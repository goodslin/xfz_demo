create procedure autoinsert()
  begin
declare i int default 1;
while(i<500000)do
insert into t1 values(i,'goodslin');
set i=i+1;
end while;
end;

